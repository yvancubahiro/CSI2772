/*MonFichier2.h : Ex2 Devoir2 CSI2772A*/


#include <iostream>
using namespace std;
const int size_tab = 10;	//nombre d'elements du tableau

void trier(int [],int );